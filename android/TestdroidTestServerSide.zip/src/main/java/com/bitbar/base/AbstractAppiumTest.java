package com.bitbar.base;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.*;
import java.net.URL;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.TimeUnit;

public abstract class AbstractAppiumTest {

    private static final String LOCAL_APPIUM_ADDRESS = "http://localhost:"+ System.getenv("APPIUM_PORT");
    // public cloud
    private static final String TESTDROID_SERVER = "https://appium.bitbar.com";
    private static final String serverSideTypeDefinition = "serverside";
    private static final String clientSideTypeDefinition = "clientside";

    protected static Logger logger = LoggerFactory.getLogger(AbstractAppiumTest.class);
    protected static AppiumDriver<MobileElement> wd;
    protected static int defaultWaitTime = 30;

    public static File userDir = new File(System.getProperty("user.dir"));
    public static File[] matches = userDir.listFiles((dir, name) -> name.startsWith("application"));

    public static String automationName = System.getenv("AUTOMATION_NAME");
    public static String deviceName = System.getenv("DEVICE_NAME") != null ? System.getenv("DEVICE_NAME") : "device";
    public static String udid = System.getenv("UDID");
    public static String platformVersion = System.getenv("PLATFORM_VERSION") != null ? System.getenv("PLATFORM_VERSION") : "";
    protected static String cs_test_run_name = System.getenv("CS_TEST_RUN_NAME");
    // client side test device
    protected static String cs_test_device = System.getenv("CS_TEST_DEVICE");
    // id of client side test apk
    protected static String cs_test_apk = System.getenv("CS_TEST_APK");

    protected String screenshotsFolder;

    public static boolean isServerSideTestRun() {
        return getExecutionType().equals(serverSideTypeDefinition);
    }

    public static boolean isClientSideTestRun() {
        return getExecutionType().equals(clientSideTypeDefinition);
    }

    protected static String getAppiumServerAddress() {
        if (isClientSideTestRun()){
            return TESTDROID_SERVER;
        }
        return LOCAL_APPIUM_ADDRESS;
    }

    private static String getTargetAppPath() {
        String propertyName = "applicationPath";
        return System.getProperty(propertyName);
    }

    private static String getApiKey() {
        String propertyName = "apiKey";
        String property = System.getProperty(propertyName);
        if (property == null || property.isEmpty()) {
            logger.warn(propertyName + " mvn argument is not defined. To define it, use the following mvn argument: -D" + propertyName + "=<insert_here>");
        }
        return property;
    }

    private static String getExecutionType() {
        String propertyName = "executionType";
        String property = System.getProperty(propertyName);
        if (property == null || property.isEmpty()) {
            logger.warn(propertyName + " mvn argument is not defined. To define it, use the following mvn argument: -D" + propertyName + "=<insert_here>");
        }
        return property;
    }

    private static boolean exportTestResultsToCloud() {
        boolean isExportResults = System.getProperty("exportResults") != null && System.getProperty("exportResults").equals("true");
        return isClientSideTestRun() && isExportResults;
    }

    protected static void exportResultsToCloud() {
        if (exportTestResultsToCloud()) {
            String folderDir = System.getProperty("alt.build.dir");
            try{
                PrintWriter writer = new PrintWriter(System.getProperty("user.dir") + "/" +folderDir+"/sessionid.txt", "UTF-8");
                writer.println(wd.getSessionId().toString());
                writer.close();
            } catch (Exception e) {
                logger.error("IOError: could not store sessionId for result exporting:"+e);
            }
        }
    }

    public static AppiumDriver getAndroidDriver() throws Exception {

        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

        automationName = System.getenv("AUTOMATION_NAME");

        if (isClientSideTestRun()) {

            if (automationName == null){
                automationName = "uiautomator2";
            }

            if (exportTestResultsToCloud()) {
                logger.debug("Exporting results enabled");
                // how long to wait for test results
                desiredCapabilities.setCapability("testdroid_junitWaitTime", 300);
            }

            desiredCapabilities.setCapability("automationName", automationName);
            desiredCapabilities.setCapability("platformName","Android");
            desiredCapabilities.setCapability("deviceName", "Android Device");
            desiredCapabilities.setCapability("appActivity", "com.testdroid.sample.android.MM_MainMenu");
            desiredCapabilities.setCapability("appPackage","com.testdroid.sample.android");

            desiredCapabilities.setCapability("testdroid_app", cs_test_apk);
            desiredCapabilities.setCapability("testdroid_apiKey", getApiKey());
            desiredCapabilities.setCapability("testdroid_target", "Android");
            desiredCapabilities.setCapability("testdroid_project", "appium_clientside");
            desiredCapabilities.setCapability("testdroid_testrun", cs_test_run_name);
            desiredCapabilities.setCapability("testdroid_device", cs_test_device);
            desiredCapabilities.setCapability("bitbar_findDevice", "false");
            // how long to wait for next test case
            desiredCapabilities.setCapability("bitbar_multiSessionWait", 60);

            // test timeout (2h, max 4h 14400)
            desiredCapabilities.setCapability("bitbar_testTimeout", 14400);

            if (platformVersion != null)
                desiredCapabilities.setCapability("platformVersion", platformVersion);

            desiredCapabilities.setCapability("newCommandTimeout", 60);
            desiredCapabilities.setCapability("fullReset", "false");
            desiredCapabilities.setCapability("noReset", "true");
        }
        else if (isServerSideTestRun()) {
            if (automationName == null) {
                automationName = "uiautomator2";
                System.out.print(automationName);
            }
            desiredCapabilities.setCapability("automationName", automationName);
            desiredCapabilities.setCapability("platformName", "Android");
            desiredCapabilities.setCapability("deviceName", "Android Device");
            desiredCapabilities.setCapability("appActivity", "com.testdroid.sample.android.MM_MainMenu");
            desiredCapabilities.setCapability("appPackage", "com.testdroid.sample.android");
            desiredCapabilities.setCapability("app", System.getProperty("user.dir") + "/application.apk");

            if (udid != null)
                desiredCapabilities.setCapability("udid", udid);
            if (platformVersion != null)
                desiredCapabilities.setCapability("platformVersion", platformVersion);

            desiredCapabilities.setCapability("newCommandTimeout", 60);
            desiredCapabilities.setCapability("fullReset", "false");
            desiredCapabilities.setCapability("noReset", "true");
        }
        else
        {
            throw new Exception("error at setting up appium driver");
        }

        log("Creating Appium session, this may take couple minutes..");
        wd = new AndroidDriver<MobileElement>(new URL(getAppiumServerAddress() + "/wd/hub"), desiredCapabilities);
        wd.manage().timeouts().implicitlyWait(defaultWaitTime, TimeUnit.SECONDS);
        return wd;
    }

    public static AppiumDriver getIOSDriver() throws Exception {
        DesiredCapabilities desiredCapabilities = new DesiredCapabilities();

        if (isClientSideTestRun()) {
            automationName = "XCUITest";
            if (platformVersion == null){
                platformVersion = "11.0";
            }

            if (exportTestResultsToCloud()) {
                logger.debug("Exporting results enabled");
                // how long to wait for test results
                desiredCapabilities.setCapability("testdroid_junitWaitTime", 300);
            }

            desiredCapabilities.setCapability("platformName", "iOS");
            desiredCapabilities.setCapability("automationName", "XCUITest");
            desiredCapabilities.setCapability("deviceName", "iOS device");
            if (udid != null)
                desiredCapabilities.setCapability("udid", udid);
            if (platformVersion != null)
                desiredCapabilities.setCapability("platformVersion", "11.0");
            desiredCapabilities.setCapability("newCommandTimeout", 120);
            desiredCapabilities.setCapability("bundleId", "com.bitbar.testdroid.BitbarIOSSample");

            desiredCapabilities.setCapability("testdroid_app", cs_test_apk);
            desiredCapabilities.setCapability("testdroid_apiKey", getApiKey());
            desiredCapabilities.setCapability("testdroid_target", "iOS");
            desiredCapabilities.setCapability("testdroid_project", "appium_clientside_ios");
            desiredCapabilities.setCapability("testdroid_testrun", cs_test_run_name);
            desiredCapabilities.setCapability("testdroid_device", cs_test_device);
            desiredCapabilities.setCapability("bitbar_findDevice", "false");
            // how long to wait for next test case
            desiredCapabilities.setCapability("bitbar_multiSessionWait", 60);
            // test timeout (2h, max 4h 14400)
            desiredCapabilities.setCapability("bitbar_testTimeout", 14400);

        }
        else if (isServerSideTestRun()) {
            automationName = "XCUITest";
            if (platformVersion == null){
                platformVersion = "11.0";
            }
            desiredCapabilities.setCapability("platformName", "iOS");
            desiredCapabilities.setCapability("automationName", "XCUITest");
            desiredCapabilities.setCapability("deviceName", "iOS device");
            desiredCapabilities.setCapability("udid", udid);
            if (platformVersion != null)
                desiredCapabilities.setCapability("platformVersion", "11.0");
            desiredCapabilities.setCapability("app", System.getProperty("user.dir") + "/application.ipa");
            desiredCapabilities.setCapability("newCommandTimeout", 120);
        }
        else
        {
            throw new Exception("error at setting up appium driver");
        }

        log("Creating Appium session, this may take couple minutes..");
        wd = new AndroidDriver<MobileElement>(new URL(getAppiumServerAddress() + "/wd/hub"), desiredCapabilities);
        wd.manage().timeouts().implicitlyWait(defaultWaitTime, TimeUnit.SECONDS);
        return wd;
    }

    //Stops the script for the given amount of seconds.
    public static void sleep(int seconds) throws InterruptedException {
        Thread.sleep(seconds * 1000);
    }

    public static void log(String message) {
        logger.info(message);
    }

    protected void swipeUp() {
        swipeUp(0.5,0.8,0.5,0.3);
    }

    protected void swipeUp(double xStartOffset, double yStartOffset,double xEndOffset, double yEndOffset) {

        //xStart, yStart swipe to xEnd, yEnd

        //0.5
        double xStart = wd.manage().window().getSize().getWidth() * xStartOffset;
        //0.8
        double yStart = wd.manage().window().getSize().getHeight() * yStartOffset;
        //0.5
        double xEnd = wd.manage().window().getSize().getWidth() * xEndOffset;
        //0.3
        double yEnd = wd.manage().window().getSize().getHeight() * yEndOffset;
        swipeUp((int)xStart, (int)yStart,(int) xEnd, (int) yEnd);
    }

    protected void swipeUp(int startX, int startY, int endX, int endY)
    {

        TouchAction action = new TouchAction(wd);

        PointOption pointOption = new PointOption();
        pointOption.withCoordinates(startX,startY);

        PointOption moveToOption = new PointOption();
        moveToOption.withCoordinates(endX,endY);

        WaitOptions waitOptions = new WaitOptions();
        waitOptions.withDuration(Duration.ofSeconds(1));

        action.press(pointOption)
                .waitAction(waitOptions).moveTo(moveToOption).release();
        action.perform();
    }

    protected void swipeDown() {
        swipeDown(0.5,0.3,0.5,0.8);
    }

    protected void swipeDown(double xStartOffset, double yStartOffset,double xEndOffset, double yEndOffset) {

        //xStart, yStart swipe to xEnd, yEnd

        //0.5
        double xStart = wd.manage().window().getSize().getWidth() * xStartOffset;
        //0.3
        double yStart = wd.manage().window().getSize().getHeight() * yStartOffset;
        //0.5
        double xEnd = wd.manage().window().getSize().getWidth() * xEndOffset;
        //0.8
        double yEnd = wd.manage().window().getSize().getHeight() * yEndOffset;
        swipeDown((int) xStart, (int) yStart, (int) xEnd, (int) yEnd);
    }

    protected void swipeDown(int startX, int startY, int endX, int endY)
    {

        TouchAction action = new TouchAction(wd);

        PointOption pointOption = new PointOption();
        pointOption.withCoordinates(startX,startY);

        PointOption moveToOption = new PointOption();
        moveToOption.withCoordinates(endX,endY);

        WaitOptions waitOptions = new WaitOptions();
        waitOptions.withDuration(Duration.ofSeconds(1));

        action.press(pointOption)
                .waitAction(waitOptions).moveTo(moveToOption).release();
        action.perform();
    }

    protected void swipeLeft() {
        swipeLeft(0.9, 0.5, 0.1, 0.5);
    }

    protected void swipeLeft(double xStartOffset, double yStartOffset,double xEndOffset, double yEndOffset) {

        //xStart, yStart swipe to xEnd, yEnd

        //0.9
        double xStart = wd.manage().window().getSize().getWidth() * xStartOffset;
        //0.5
        double yStart = wd.manage().window().getSize().getHeight() * yStartOffset;
        //0.1
        double xEnd = wd.manage().window().getSize().getWidth() * xEndOffset;
        //0.5
        double yEnd = wd.manage().window().getSize().getHeight() * yEndOffset;
        swipeLeft((int)xStart, (int)yStart,(int) xEnd, (int) yEnd);
    }

    protected void swipeLeft(int startX, int startY, int endX, int endY)
    {

        TouchAction action = new TouchAction(wd);

        PointOption pointOption = new PointOption();
        pointOption.withCoordinates(startX,startY);

        PointOption moveToOption = new PointOption();
        moveToOption.withCoordinates(endX,endY);

        WaitOptions waitOptions = new WaitOptions();
        waitOptions.withDuration(Duration.ofSeconds(1));

        action.press(pointOption)
                .waitAction(waitOptions).moveTo(moveToOption).release();
        action.perform();
    }

    protected void swipeRight() {
        swipeRight(0.1,0.5,0.9,0.5);
    }

    protected void swipeRight(double xStartOffset, double yStartOffset,double xEndOffset, double yEndOffset) {

        //xStart, yStart swipe to xEnd, yEnd

        //0.1
        double xStart = wd.manage().window().getSize().getWidth() * xStartOffset;
        //0.5
        double yStart = wd.manage().window().getSize().getHeight() * yStartOffset;
        //0.9
        double xEnd = wd.manage().window().getSize().getWidth() * xEndOffset;
        //0.5
        double yEnd = wd.manage().window().getSize().getHeight() * yEndOffset;
        swipeRight((int)xStart, (int)yStart,(int) xEnd, (int) yEnd);
    }

    protected void swipeRight(int startX, int startY, int endX, int endY)
    {

        TouchAction action = new TouchAction(wd);

        PointOption pointOption = new PointOption();
        pointOption.withCoordinates(startX,startY);

        PointOption moveToOption = new PointOption();
        moveToOption.withCoordinates(endX,endY);

        WaitOptions waitOptions = new WaitOptions();
        waitOptions.withDuration(Duration.ofSeconds(1));

        action.press(pointOption)
                .waitAction(waitOptions).moveTo(moveToOption).release();
        action.perform();
    }

    protected void myTap(int pointX, int pointY)
    {
        TouchAction action = new TouchAction(wd);

        PointOption pointOption = new PointOption();
        pointOption.withCoordinates(pointX,pointY);

        WaitOptions waitOptions = new WaitOptions();
        waitOptions.withDuration(Duration.ofMillis(200));

        action.press(pointOption)
                .waitAction(waitOptions).release();
        action.perform();
    }

    public String takeScreenShot(String screenshotName) throws Exception {

        screenshotsFolder = System.getenv("SCREENSHOT_FOLDER");
        if (screenshotsFolder == null || screenshotsFolder.isEmpty()) {
            screenshotsFolder = "target/reports/screenshots/";
        }

        long start_time = System.nanoTime();

        String screenshotFile = screenshotsFolder + screenshotName + ".png";
        String screenShotFilePath = System.getProperty("user.dir") + "/" + screenshotFile;

        takeScreenshot(screenShotFilePath);

        long end_time = System.nanoTime();
        int difference = (int) ((end_time - start_time) / 1e6 / 1000);
        logger.info("==> Taking a screenshot took " + difference + " secs.");
        return screenshotFile;
    }

    private static void takeScreenshot(String screenShotFilePath) throws IOException {

        String fullFileName = screenShotFilePath;

        try {
            logger.debug("Taking screenshot...");
            File scrFile = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
            File testScreenshot = new File(fullFileName);
            FileUtils.copyFile(scrFile, testScreenshot);
            logger.debug("Screenshot stored to " + testScreenshot.getAbsolutePath());
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static String executeMobileShell(String command) throws Exception {

        Map<String, Object> args = new HashMap<>();
        args.put("command", command);
        String output = (String) wd.executeScript("mobile: shell", args);
        return output;
    }
}
