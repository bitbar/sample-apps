package com.sample.app.ios;

import io.appium.java_client.MobileElement;
import junit.framework.AssertionFailedError;
import org.junit.Assert;
import org.junit.ComparisonFailure;
import org.junit.Test;
import org.openqa.selenium.By;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class IOSAppLaunchTest extends AbstractIosTest {

    @Test
    public void a_openAppTest() throws Exception {

        // open app: https://github.com/bitbar/bitbar-samples/blob/master/apps/ios/bitbar-ios-sample.ipa
        // select answer 2, type name, click ´answer´
        // expect to see 'You are right!'

        try {
            log("start: " + getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName());
            openApp();
        } catch (Exception | ComparisonFailure | AssertionFailedError e) {
            takeScreenShot(getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName() + "_failed");
            System.out.println(wd.getPageSource());
            throw e;
        }
    }

    public void openApp() throws Exception {

        boolean buttonFound = false;

        // wait 10 seconds for element to be found
        wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        sleep(10);
        takeScreenShot("app open");
        sleep(1);

        List<MobileElement> buttons = wd.findElements(By.className("XCUIElementTypeButton"));
        MobileElement button;

        for (int i = 0; i < buttons.size(); i++)
        {
            button = buttons.get(i);
            if (button.getAttribute("name").contains("answer2"))
            {
                button.click();
                buttonFound = true;
                sleep(1);
                break;
            }
        }

        if (!buttonFound)
        {
            buttons = wd.findElements(By.className("XCUIElementTypeButton"));
            for (int i = 0; i < buttons.size(); i++)
            {
                button = buttons.get(i);
                if (button.getAttribute("label").contains("answer2"))
                {
                    button.click();
                    buttonFound = true;
                    sleep(1);
                    break;
                }
            }
        }

        if (!buttonFound)
        {
            buttons = wd.findElements(By.className("XCUIElementTypeButton"));
            buttons.get(3).click();
            sleep(1);
        }

        wd.findElement(By.className("XCUIElementTypeTextField")).click();
        sleep(1);
        wd.findElement(By.className("XCUIElementTypeTextField")).sendKeys("bitbar");
        sleep(1);
        try
        {
            wd.hideKeyboard();
        }
        catch (Exception e)
        {}
        sleep(1);

        buttons = wd.findElements(By.className("XCUIElementTypeButton"));

        for (int i = 0; i < buttons.size(); i++)
        {
            button = buttons.get(i);
            if (button.getAttribute("name").contains("sendAnswer"))
            {
                button.click();
                sleep(1);
                break;
            }
        }

        List<MobileElement> textElements = wd.findElements(By.className("XCUIElementTypeStaticText"));
        MobileElement textElement;

        for (int i = 0; i < textElements.size(); i++)
        {
            textElement = textElements.get(i);
            if (textElement.getAttribute("name").contains("You are right!"))
            {
                break;
            }
        }

        Assert.assertEquals("You are right!", wd.findElements(By.className("XCUIElementTypeStaticText")).get(0).getAttribute("value"));
        takeScreenShot("correct answer");
    }
}
