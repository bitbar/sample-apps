package com.sample.app.ios;

import com.bitbar.base.AbstractAppiumTest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class AbstractIosTest extends AbstractAppiumTest {

    public AbstractIosTest() {
        super();
        logger = LoggerFactory.getLogger(AbstractIosTest.class);
    }

    public static void quitAppiumSession(){
        exportResultsToCloud();
        if (wd != null) {
            wd.quit();
        }
    }

    @BeforeClass
    public static void setUp() throws Exception {
        wd = getIOSDriver();
    }

    @AfterClass
    public static void tearDown() {
        quitAppiumSession();
    }

    @Before
    public void setUpTest() throws Exception {
        log("Setting implicit wait to " + defaultWaitTime + " seconds");
        wd.manage().timeouts().implicitlyWait(defaultWaitTime, TimeUnit.SECONDS);
    }

    @After
    public void tearDownTest() {
        wd.resetApp();
    }
}
