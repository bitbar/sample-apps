package com.sample.app.android;

import junit.framework.AssertionFailedError;
import org.junit.Assert;
import org.junit.ComparisonFailure;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;

import java.util.concurrent.TimeUnit;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AndroidAppLaunchTest extends AbstractAndroidTest {

    @Test
    public void a_openAppAndTapNativeActivityTest() throws Exception {

        // open app: https://github.com/bitbar/bitbar-samples/blob/master/apps/android/testdroid-sample-app.apk
        // and check that 'Native Activity' button takes to correct view

        try {
            log("start: " + getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName());
            openAppTapNativeActivity();
        } catch (Exception | ComparisonFailure | AssertionFailedError e) {
            takeScreenShot(getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName() + "_failed");
            System.out.println(wd.getPageSource());
            throw e;
        }
    }

    @Test
    public void b_openAppAndTapDeviceInfoTest() throws Exception {

        // open app: https://github.com/bitbar/bitbar-samples/blob/master/apps/android/testdroid-sample-app.apk
        // and check that 'Device Info' button takes to correct view

        try {
            log("start: " + getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName());
            openAppTapDeviceInfo();
        } catch (Exception | ComparisonFailure | AssertionFailedError e) {
            takeScreenShot(getClass().getSimpleName() + "-" + Thread.currentThread().getStackTrace()[1].getMethodName() + "_failed");
            System.out.println(wd.getPageSource());
            throw e;
        }
    }

    public void openAppTapNativeActivity() throws Exception {

        // wait 10 seconds for element to be found
        wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        // look for 'Native Activity'
        wd.findElement(By.id(resNativeButton)).isDisplayed();
        log("Native Activity visible");
        // click 'Native Activity'
        wd.findElement(By.id(resNativeButton)).click();
        log("Native Activity clicked");
        // look for score text view
        wd.findElement(By.id(resScoreTextView)).isDisplayed();
        log("score number visible");
        // take screenshot
        takeScreenShot("NativeActivity clicked");
        sleep(1);

    }

    public void openAppTapDeviceInfo() throws Exception {

        // wait 10 seconds for element to be found
        wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        // look for 'Device Info'
        wd.findElement(By.id(resDeviceInfoButton)).isDisplayed();
        log("Device Info visible");
        // click 'Device Info'
        wd.findElement(By.id(resDeviceInfoButton)).click();
        log("Device Info clicked");
        // look for title text view (title)
        wd.findElement(By.id(resDeviceInfoTitleTextView)).isDisplayed();
        log("title visible");
        // take screenshot
        takeScreenShot("Device Info clicked");
        // check that title is 'Device info'
        Assert.assertEquals("Device Info", wd.findElement(By.id(resDeviceInfoTitleTextView)).getAttribute("text"));
    }
}
