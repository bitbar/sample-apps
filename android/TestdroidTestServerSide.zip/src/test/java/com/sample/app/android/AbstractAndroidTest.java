package com.sample.app.android;

import com.bitbar.base.AbstractAppiumTest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;

public class AbstractAndroidTest extends AbstractAppiumTest {

    // app element locators (resource-id)

    protected static String resNativeButton = "mm_b_native";
    protected static String resScoreTextView = "na_tv_score";

    protected static String resDeviceInfoButton = "mm_b_deviceInfo";
    // different package name
    protected static String resDeviceInfoTitleTextView = "android:id/action_bar_title";


    public AbstractAndroidTest() {
        super();
        logger = LoggerFactory.getLogger(AbstractAndroidTest.class);
    }

    public static void quitAppiumSession(){
        exportResultsToCloud();
        if (wd != null) {
            wd.quit();
        }
    }

    @BeforeClass
    public static void setUp() throws Exception {
        wd = getAndroidDriver();
    }

    @AfterClass
    public static void tearDown() {
        quitAppiumSession();
    }

    @Before
    public void setUpTest() throws Exception {
        log("Setting implicit wait to " + defaultWaitTime + " seconds");
        wd.manage().timeouts().implicitlyWait(defaultWaitTime, TimeUnit.SECONDS);
    }

    @After
    public void tearDownTest() {
        wd.resetApp();
    }
}
