#!/bin/bash

## Environment variables setup
export PLATFORM_NAME="Android"
export UDID=${ANDROID_SERIAL}
export APPIUM_PORT="4723"

APILEVEL=$(adb shell getprop ro.build.version.sdk)
APILEVEL="${APILEVEL//[$'\t\r\n']}"
export PLATFORM_VERSION=${APILEVEL}
echo "API level is: ${APILEVEL}"
if [ "$APILEVEL" -gt "19" ]; then
	export AUTOMATION_NAME="UiAutomator2"
	echo "UiAutomator2"
else
	export AUTOMATION_NAME="UiAutomator1"
	echo "UiAutomator1"
fi

# test class name
TEST=${TEST:="AndroidAppLaunchTest"}

# create test run folder for test files
mkdir -p temp_test_report
chmod 0755 temp_test_report/

results=results/android/$UDID/$(date +%Y-%m-%d-%H-%M)
mkdir -p ${results}
maven_folder=temp_test_report/target/reports/android/$UDID/$(date +%Y-%m-%d-%H-%M)
mkdir -p ${maven_folder}
mkdir -p ${maven_folder}/screenshots
export SCREENSHOT_FOLDER=${maven_folder}/screenshots/

# Set $DATE variable
DATE=`date +%Y-%m-%d:%H:%M:%S`

echo "Extracting tests.zip..."
unzip tests.zip

# start appium
appium --log-no-colors --log-timestamp  --command-timeout 60  > appium.log 2>&1 &

# start maven test
mvn clean test -Dtest=${TEST} -Dalt.build.dir=${maven_folder}/ -DexecutionType=serverside

# move test results and screenshots from temporary folder to results folder

rm -rf screenshots
rm TEST-all.xml

mkdir -p screenshots

mv ${maven_folder}/TEST-*.xml TEST-all.xml
mv ${maven_folder}/screenshots screenshots

