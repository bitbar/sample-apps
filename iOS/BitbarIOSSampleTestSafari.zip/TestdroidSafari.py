##
## Appium iOS Server Side Safari Test
##

import os
import unittest
from appium import webdriver
from time import sleep
import time
import xmlrunner
from TestdroidAppiumTest import TestdroidAppiumTest, log
from selenium.common.exceptions import NoSuchElementException

class TestdroidSafari(TestdroidAppiumTest):

    def setUp(self):
        # TestdroidAppiumTest takes settings (local or cloud) from environment variables
        super(TestdroidSafari, self).setUp()

    def testSample(self):
        driver = self.get_driver()
        sleep(20)
        driver.get("https://bitbar.github.io/web-testing-target/")
        sleep(10)
        driver.save_screenshot(self.screenshot_dir + "/1_home_screen.png")

        log("  Sitching to landscape")
        driver.orientation = "LANDSCAPE"
        driver.save_screenshot(self.screenshot_dir + "/2_home_landscape.png")
        log("  Switching to portrait")
        driver.orientation = "PORTRAIT"
        driver.save_screenshot(self.screenshot_dir + "/3_home_portrait.png")

        log("Finding button with text 'Click for answer'")
        button = self.wait_until_xpath_matches('//button[contains(., "Click for answer")]', timeout=20, driver=driver)

        log("Clicking on button")
        button.click()
        driver.save_screenshot(self.screenshot_dir + "/4_answer.png")

        log("Check answer text")
        elem = driver.find_element_by_xpath('//p[@id="result_element" and contains(., "Bitbar")]')

        log("Verify button changed color")
        style = str(button.get_attribute('style'))
        expected_style = "rgb(127, 255, 0"
        self.assertTrue(expected_style in style)


    def wait_until_xpath_matches(self, xpath, timeout=10, step=1, driver=None):
        end_time = time.time() + timeout 
        found = False
        while (time.time() < end_time and not found):
            log("  {:.1}: Looking for xpath {}".format(end_time - time.time(), xpath))
            try:
                elem = driver.find_element_by_xpath(xpath)
                found = True
            except NoSuchElementException:
                found = False
            time.sleep(step)
        if not found:
            print "  Page source\n{}\n".format(driver.page_source)
            raise NoSuchElementException("Element wiht xpath: '{}' not found in {}s".format(xpath, timeout))
        return elem



# if __name__ == "__main__":
#     suite = unittest.TestLoader().loadTestsFromTestCase(TestdroidSafari)
#     unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    unittest.main(testRunner=xmlrunner.XMLTestRunner(output='test-reports'))

